package com;

public class Demo {

	public static void main(String[] args) {
		System.out.println("hi");

		try {
			Class.forName("com.D");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found enter proper class Name");
		}

		System.out.println("bye");
	}
}
